import { test } from "node:test";
import assert from "node:assert/strict";
import { emptyData } from "../src/model";
test("web persistence survives fresh loads and failed write leaves saved data intact", async () => {
  const values = new Map<string, string>();
  let full = false;
  Object.defineProperty(globalThis, "localStorage", {
    value: {
      getItem: (k: string) => values.get(k) || null,
      setItem: (k: string, v: string) => {
        if (full) throw new Error("quota exceeded");
        values.set(k, v);
      },
    },
    configurable: true,
  });
  const { load, save } = await import("../src/storage.web");
  const d = emptyData();
  d.lists.push("Saved list");
  await save(d);
  assert.deepEqual(await load(), d);
  full = true;
  await assert.rejects(save(emptyData()));
  assert.deepEqual(await load(), d);
});
