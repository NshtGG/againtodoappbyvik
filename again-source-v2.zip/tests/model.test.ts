import { test } from "node:test";
import assert from "node:assert/strict";
import {
  Task,
  dates,
  emptyData,
  occurrences,
  toggle,
  editTask,
  deleteTask,
  addDays,
  parseBackup,
  matches,
  validateTask,
} from "../src/model";
import { reminderPlan } from "../src/reminderPlan";
const task = (p: Partial<Task> = {}): Task => ({
  id: "workout",
  title: "Workout",
  notes: "",
  start: "2026-10-02",
  end: "2026-12-31",
  time: "",
  repeat: "daily",
  interval: 1,
  weekdays: [1, 3, 5],
  priority: 0,
  list: "Health",
  reminder: null,
  createdAt: "2026-10-02T00:00:00Z",
  ...p,
});
const data = () => ({ ...emptyData(), tasks: [task()] });
test("91 inclusive daily dates with no duplicates", () => {
  const ds = dates(task(), "2026-01-01", "2027-01-01");
  assert.equal(ds.length, 91);
  assert.equal(new Set(ds).size, 91);
  assert.equal(ds.at(-1), "2026-12-31");
});
test("each occurrence completes independently and completion is reversible", () => {
  let d = data();
  const os = occurrences(d, "2026-10-02", "2026-10-03");
  d = toggle(d, os[0]);
  const rows = occurrences(d, "2026-10-02", "2026-10-03");
  assert.ok(rows[0].completedAt);
  assert.equal(rows[1].completedAt, undefined);
  d = toggle(d, rows[0]);
  assert.equal(
    occurrences(d, "2026-10-02", "2026-10-02")[0].completedAt,
    undefined,
  );
});
test("single occurrence edit does not change its neighbor", () => {
  const d = data(),
    o = occurrences(d, "2026-10-02", "2026-10-02")[0];
  const next = editTask(d, o, { ...o.task, title: "Gentle workout" }, "one");
  const os = occurrences(next, "2026-10-02", "2026-10-03");
  assert.equal(os[0].task.title, "Gentle workout");
  assert.equal(os[1].task.title, "Workout");
});
test("future edit splits series and preserves prior history", () => {
  let d = data();
  d = toggle(d, occurrences(d, "2026-10-02", "2026-10-02")[0]);
  const o = occurrences(d, "2026-10-03", "2026-10-03")[0];
  d = editTask(d, o, { ...o.task, title: "New workout" }, "future");
  const os = occurrences(d, "2026-10-02", "2026-10-04");
  assert.equal(os.length, 3);
  assert.equal(os[0].task.title, "Workout");
  assert.ok(os[0].completedAt);
  assert.equal(os[1].task.title, "New workout");
});
test("whole series rule edit retains completed historical snapshot", () => {
  let d = data();
  const o = occurrences(d, "2026-10-02", "2026-10-02")[0];
  d = toggle(d, o);
  d = editTask(
    d,
    o,
    { ...o.task, title: "Renamed", start: "2026-10-10", repeat: "weekly" },
    "all",
  );
  assert.equal(
    occurrences(d, "2026-10-02", "2026-10-02")[0].task.title,
    "Workout",
  );
});
test("delete scopes and completed history", () => {
  let d = data();
  const o = occurrences(d, "2026-10-02", "2026-10-02")[0];
  assert.equal(
    occurrences(deleteTask(d, o, "one"), "2026-10-02", "2026-10-03").length,
    1,
  );
  d = toggle(d, o);
  assert.equal(
    occurrences(deleteTask(d, o, "all"), "2026-10-02", "2026-10-10").length,
    1,
  );
});
test("weekdays and selected weekdays", () => {
  assert.deepEqual(
    dates(task({ repeat: "weekdays" }), "2026-10-02", "2026-10-05"),
    ["2026-10-02", "2026-10-05"],
  );
  assert.deepEqual(
    dates(task({ repeat: "selected" }), "2026-10-02", "2026-10-08"),
    ["2026-10-02", "2026-10-05", "2026-10-07"],
  );
});
test("monthly clamps without drifting, leap year and year rollover", () => {
  assert.deepEqual(
    dates(
      task({ start: "2024-01-31", end: "2024-04-30", repeat: "monthly" }),
      "2024-01-01",
      "2024-05-01",
    ),
    ["2024-01-31", "2024-02-29", "2024-03-31", "2024-04-30"],
  );
  assert.equal(addDays("2026-12-31", 1), "2027-01-01");
  assert.equal(addDays("2024-02-28", 1), "2024-02-29");
});
test("intervals remain anchored to start date", () => {
  assert.deepEqual(
    dates(
      task({ repeat: "intervalDays", interval: 3 }),
      "2026-10-03",
      "2026-10-10",
    ),
    ["2026-10-05", "2026-10-08"],
  );
  assert.deepEqual(
    dates(
      task({ repeat: "intervalWeeks", interval: 2 }),
      "2026-10-02",
      "2026-10-31",
    ),
    ["2026-10-02", "2026-10-16", "2026-10-30"],
  );
});
test("date calculations do not change across timezones or DST", () => {
  const old = process.env.TZ;
  for (const tz of [
    "UTC",
    "America/New_York",
    "Asia/Kolkata",
    "Pacific/Auckland",
  ]) {
    process.env.TZ = tz;
    assert.deepEqual(
      dates(
        task({ start: "2026-03-07", end: "2026-03-10" }),
        "2026-03-07",
        "2026-03-10",
      ),
      ["2026-03-07", "2026-03-08", "2026-03-09", "2026-03-10"],
    );
  }
  process.env.TZ = old;
});
test("backup round trip preserves state and rejects malformed data", () => {
  let d = data();
  d = toggle(d, occurrences(d, "2026-10-02", "2026-10-02")[0]);
  assert.deepEqual(parseBackup(JSON.stringify(d)), d);
  assert.throws(() => parseBackup('{"version":2}'));
  const invalid = data();
  invalid.tasks[0].interval = 0;
  assert.throws(() => parseBackup(JSON.stringify(invalid)));
});
test("invalid dates, times, ranges and empty selected days rejected", () => {
  assert.ok(validateTask(task({ start: "2026-02-30" })));
  assert.ok(validateTask(task({ time: "25:00" })));
  assert.ok(validateTask(task({ end: "2026-01-01" })));
  assert.ok(validateTask(task({ repeat: "selected", weekdays: [] })));
});
test("reminder plan omits completed occurrences, limits queue and disables cleanly", () => {
  const now = new Date(),
    date = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  let d = {
    ...data(),
    tasks: [
      task({
        start: addDays(date, 1),
        end: undefined,
        time: "12:00",
        reminder: 15,
      }),
    ],
  };
  d.settings.notifications = true;
  const p = reminderPlan(d, now);
  assert.ok(p.length <= 60);
  assert.equal(p[0].date.getMinutes(), 45);
  d = toggle(d, occurrences(d, addDays(date, 1), addDays(date, 1))[0]);
  assert.notEqual(reminderPlan(d, now)[0].id, p[0].id);
  d.settings.notifications = false;
  assert.deepEqual(reminderPlan(d, now), []);
});
