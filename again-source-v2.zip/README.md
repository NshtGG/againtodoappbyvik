# Again

A free, offline-first recurring task manager for Android, iOS, and web. Built with React Native, TypeScript, Expo SDK 55, and Expo Router.

## Start here

Install Node.js 22 LTS (or a supported newer release) and pnpm. From this folder:

```sh
corepack enable
pnpm install --frozen-lockfile
pnpm web
```

If Corepack is unavailable, install pnpm using its official installation instructions. Dependencies are pinned in `pnpm-lock.yaml`; do not independently upgrade React or React Native.

For a production web export:

```sh
pnpm build:web
pnpm dlx serve dist
```

Serve the exported directory over HTTP, rather than opening `index.html` as a file. HTTPS or localhost is required for the service worker. After the first complete online load, the app shell can reopen offline. Tasks are stored in the current browser profile. Clearing site data deletes them; export backups regularly. Separate browsers, ports, and deployment origins have separate workspaces.

## Android

### Run locally

Install Android Studio, its SDK/emulator, and JDK 17. Configure `ANDROID_HOME` and your Java environment using the [Expo Android environment guide](https://docs.expo.dev/workflow/android-studio-emulator/). Start an emulator or connect a device with USB debugging enabled.

```sh
pnpm android
```

Expo generates the native Android project automatically. To run Metro for an existing build:

```sh
pnpm start
```

### Installable standalone testing APK

An Expo account is needed for the optional EAS cloud build service, not for using the app. Authenticate and initialize/link your own project when prompted. No EAS identity or signing keys are bundled.

```sh
pnpm dlx eas-cli login
pnpm dlx eas-cli build:configure
pnpm dlx eas-cli build --platform android --profile preview
```

The `preview` profile produces an APK. Download the APK from the resulting build page and install it on an Android device. This standalone build does not require Metro. EAS availability and quotas are controlled by Expo; local builds are an alternative.

### Android App Bundle for Play Console

Choose a unique application ID in `app.json` before publishing. Keep the signing key secure and use the same key for future updates.

```sh
pnpm dlx eas-cli build --platform android --profile production
```

The `production` profile produces a signed AAB after your credentials are configured. An AAB is for Play Console and is not directly installable. Store enrollment, listing assets, privacy disclosures, testing requirements, and signing configuration remain the publisher's responsibility.

For a local release build without EAS, generate the native project with `pnpm exec expo prebuild --platform android`, configure your release signing in Android Studio, and build a signed APK or AAB. See the [official local release instructions](https://docs.expo.dev/guides/local-app-production/). Never distribute the debug keystore as a production signing key.

## iOS

Local compilation needs macOS, Xcode, CocoaPods, and the iOS simulator or a provisioned device:

```sh
pnpm install --frozen-lockfile
pnpm ios
```

Alternatively, configure your Apple credentials and run `pnpm dlx eas-cli build --platform ios --profile production`. Device distribution and App Store publishing require appropriate Apple signing and enrollment. Windows can develop and export the shared JavaScript but cannot run Xcode or an iOS simulator.

## Features

- Quick add, notes, due dates/times, four priority levels, and custom lists.
- Today, Upcoming, Calendar, All tasks, completion history, and overdue tasks.
- Title/notes search, list/priority/status filters, and date/priority sorting.
- Daily, weekdays, weekly, selected weekdays, monthly, every N days, and every N weeks.
- A start date and optional inclusive end date for every recurring rule. Combine them with selected weekdays or intervals to build custom date ranges.
- Independent occurrence checkboxes; deterministic date keys prevent duplication.
- Edit one occurrence's details, split at an occurrence for future changes, or edit the series. Schedule changes use future/whole-series scope; single-occurrence edits preserve their scheduled date.
- Delete one occurrence, this and future occurrences, or archive the series. Series deletion preserves completed history. Individual deletion hides that occurrence, including its completion, and Undo restores it.
- Undo the most recent saved change during the current session.
- Monochrome system/light/dark themes and configurable week start.
- Native local reminder scheduling, permission handling, and offsets.
- JSON backup export, validated import, and confirmed workspace deletion.
- Extras: focus timer with daily minutes, priority-based next-task suggestion, and six-date recurrence preview.

## Data and recurrence design

`src/model.ts` is the platform-independent domain layer. Recurrence uses date-only `YYYY-MM-DD` strings and UTC calendar arithmetic. Device-local time is used only when creating notification timestamps. Moving between timezones never changes task date identities. Monthly tasks clamp to the last valid day without shifting the original anchor. Dates are generated on demand within requested windows; no infinite series is materialized.

Completion and overrides are stored separately under `seriesId:date`. A completed occurrence stores a snapshot. Future edits split the series and transfer future exceptions, preserving history. Whole-series edits retain completion snapshots even if the new rule no longer includes their date.

Native persistence uses Expo SQLite with WAL and an atomic, versioned JSON state row. This keeps the local transaction consistent across task, exception, and settings changes. Web uses localStorage through the same storage interface. Mutations queue their writes; state updates after a successful save. The domain and storage interfaces are separated so a future sync repository can replace the local storage adapter.

## Platform behavior and limits

- Native reminders schedule up to the next **60 occurrences within 60 days** across the workspace. Opening/foregrounding the app, changing tasks, or changing settings refreshes the queue and cancels obsolete reminders. Open the app regularly to keep long-running routines scheduled.
- Reminders must be enabled in Settings. Permission denial is handled without blocking tasks. Android battery restrictions and OS scheduling can delay delivery; this app does not request exact-alarm privileges. Do not treat it as a safety-critical alarm.
- Reminder wall-clock times are reinterpreted in the current device timezone on refresh. Until refresh, existing OS notifications keep their scheduled instant. Nonexistent DST times follow the platform's next-valid-time adjustment.
- Web does not promise background notifications. Reminder choices remain portable in backups to native apps.
- Focus timers catch up after a suspended tab returns, but do not issue a background alarm or survive an app process restart. A session is counted when its running timer reaches zero in the app.
- All tasks starts with a bounded date window; expand it in 30-day steps. Today's overdue section covers the previous 90 days and shows the latest 20; older dates remain browsable in Calendar/All tasks. Completion history retains all recorded completions.
- Touch uses explicit buttons and menus rather than swipe gestures. There is no cloud sync or app account. The private hosted web preview may have a hosting access gate; the standalone app itself has no login.
- SQLite uses a versioned state row rather than normalized per-task SQL tables. For exceptionally large histories, a paginated SQL repository is the natural next step.

## Verification

```sh
pnpm typecheck
pnpm test
pnpm exec expo install --check
pnpm exec expo export --platform android --output-dir ../../work/android-export
pnpm exec expo export --platform ios --output-dir ../../work/ios-export
pnpm build:web
```

Tests cover inclusive date ranges, independent completion, occurrence edits, series splits, retained history, deletion scopes, weekdays, intervals, month ends, leap years, year boundaries, DST/timezone invariance, backup validation, reminder planning, and web storage reload/failure behavior.

Web browser checks covered daily task creation with an end date, completing today without completing tomorrow, and reloading saved data. TypeScript, dependency compatibility, and Android/iOS/web bundling were checked in the build environment.

**No APK/AAB/IPA was compiled or installed here.** This environment had no Android SDK, JDK, emulator/device, Xcode, or configured EAS credentials. Native SQLite execution and OS notification delivery therefore still need device smoke tests. A JavaScript/Hermes bundle export is not an Android or iOS binary.

Device release smoke test: create Workout daily over a range, complete today, inspect tomorrow, force-stop/reopen, verify history, set a reminder a few minutes ahead, background the app, verify delivery, edit the reminder and verify the obsolete one is cancelled, then export/import a backup and test both themes.

References: [Expo SQLite](https://docs.expo.dev/versions/v55.0.0/sdk/sqlite/), [Expo notifications](https://docs.expo.dev/versions/v55.0.0/sdk/notifications/), [EAS first build](https://docs.expo.dev/build/setup/).
