import React from "react";
import {
  Pressable,
  Text,
  View,
  TextInput,
  useColorScheme,
  StyleSheet,
} from "react-native";
import createIconSet from "@expo/vector-icons/createIconSet";
import glyphMap from "@expo/vector-icons/build/vendor/react-native-vector-icons/glyphmaps/Feather.json";
import { useStore } from "./provider";
const Feather = createIconSet(glyphMap, "AgainFeather", require("../assets/Feather.ttf"));
export function useTheme() {
  const { data } = useStore(),
    system = useColorScheme();
  const dark =
    data.settings.theme === "dark" ||
    (data.settings.theme === "system" && system === "dark");
  const palette = data.settings.theme === "rose"
    ? { bg: "#fff5f7", surface: "#ffffff", ink: "#4b1726", muted: "#8f6170", line: "#efcad4", soft: "#f9dfe6", inverse: "#fff8fa" }
    : data.settings.theme === "ocean"
      ? { bg: "#eff9fb", surface: "#ffffff", ink: "#073f4d", muted: "#527985", line: "#bedfe5", soft: "#dceff2", inverse: "#f6fdff" }
      : data.settings.theme === "forest"
        ? { bg: "#f3f8f1", surface: "#ffffff", ink: "#183c27", muted: "#607a67", line: "#c9ddcb", soft: "#e1eee2", inverse: "#f8fff8" }
        : null;
  if (palette) return { dark: false, ...palette };
  return {
    dark,
    bg: dark ? "#101010" : "#f7f7f3",
    surface: dark ? "#181818" : "#ffffff",
    ink: dark ? "#f5f5f0" : "#171717",
    muted: dark ? "#a4a4a0" : "#696966",
    line: dark ? "#363636" : "#dcdcd5",
    soft: dark ? "#242424" : "#eeeeE8",
    inverse: dark ? "#161616" : "#fafaf7",
  };
}
export function Txt({ children, style, ...props }: any) {
  const c = useTheme();
  return (
    <Text
      {...props}
      style={[{ color: c.ink, fontSize: 15, lineHeight: 23 }, style]}
    >
      {children}
    </Text>
  );
}
export function Icon({ name, size = 20, color }: any) {
  const c = useTheme();
  return <Feather name={name} size={size} color={color || c.ink} />;
}
export function Button({
  children,
  onPress,
  primary = false,
  small = false,
  icon,
  disabled = false,
  style,
  label,
}: any) {
  const c = useTheme();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        {
          minHeight: 44,
          paddingHorizontal: small ? 13 : 20,
          paddingVertical: small ? 10 : 13,
          borderRadius: 8,
          borderWidth: 1,
          borderColor: primary ? c.ink : c.line,
          backgroundColor: primary ? c.ink : c.surface,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          gap: 9,
          opacity: disabled ? 0.4 : pressed ? 0.65 : 1,
        },
        style,
      ]}
    >
      {icon && (
        <Icon name={icon} size={17} color={primary ? c.inverse : c.ink} />
      )}
      <Txt
        style={{
          fontWeight: "700",
          fontSize: small ? 12 : 14,
          color: primary ? c.inverse : c.ink,
        }}
      >
        {children}
      </Txt>
    </Pressable>
  );
}
export function Input({ label, style, ...props }: any) {
  const c = useTheme();
  return (
    <View style={{ gap: 7 }}>
      {label && <Txt style={styles.label}>{label}</Txt>}
      <TextInput
        accessibilityLabel={label}
        placeholderTextColor={c.muted}
        {...props}
        style={[
          {
            color: c.ink,
            backgroundColor: c.surface,
            borderColor: c.line,
            borderWidth: 1,
            borderRadius: 8,
            padding: 13,
            fontSize: 15,
            minHeight: 48,
          },
          style,
        ]}
      />
    </View>
  );
}
export const styles = StyleSheet.create({
  label: {
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.8,
    lineHeight: 17,
  },
  row: { flexDirection: "row", alignItems: "center", gap: 10 },
  wrap: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  heading: {
    fontSize: 46,
    fontWeight: "900",
    letterSpacing: -2,
    lineHeight: 52,
  },
  card: { padding: 24, borderWidth: 1, borderRadius: 12, gap: 18 },
});
