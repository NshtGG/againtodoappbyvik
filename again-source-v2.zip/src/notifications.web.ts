import { Data } from "./model";
export async function permission(_request = false) {
  return "unavailable on web";
}
export async function syncReminders(_data: Data) {}
