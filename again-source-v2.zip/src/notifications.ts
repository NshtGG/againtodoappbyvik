import * as N from "expo-notifications";
import { Platform } from "react-native";
import { Data } from "./model";
import { reminderPlan } from "./reminderPlan";
N.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});
export async function permission(request = false) {
  if (Platform.OS === "android") {
    for (const tone of ["gentle", "bright", "focus"])
      await N.setNotificationChannelAsync(`tasks-${tone}`, {
        name: `Task reminders · ${tone}`,
        importance: N.AndroidImportance.HIGH,
        sound: `${tone}.wav`,
      });
    await N.setNotificationChannelAsync("tasks-silent", {
      name: "Task reminders · silent",
      importance: N.AndroidImportance.HIGH,
      sound: null,
    });
  }
  const p = await N.getPermissionsAsync();
  if (p.granted) return "granted";
  if (request) {
    const r = await N.requestPermissionsAsync();
    return r.granted ? "granted" : "denied";
  }
  return p.status;
}
let queue = Promise.resolve();
export function syncReminders(data: Data) {
  const run = queue
    .catch(() => {})
    .then(async () => {
      await N.cancelAllScheduledNotificationsAsync();
      if (!data.settings.notifications || (await permission()) !== "granted")
        return;
      for (const p of reminderPlan(data)) {
        await N.scheduleNotificationAsync({
          identifier: p.id,
          content: {
            title: p.title,
            body: "A little progress. Again.",
            sound: p.ringtone === "silent" ? undefined : `${p.ringtone}.wav`,
            data: { key: p.id },
          },
          trigger: {
            type: N.SchedulableTriggerInputTypes.DATE,
            date: p.date,
            channelId: `tasks-${p.ringtone}`,
          },
        });
      }
    });
  queue = run;
  return run;
}
