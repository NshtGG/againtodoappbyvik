import { Data, emptyData, parseBackup } from "./model";
const KEY = "again.tasks.v1";
export async function load(): Promise<Data> {
  const raw = localStorage.getItem(KEY);
  return raw ? parseBackup(raw) : emptyData();
}
export async function save(data: Data) {
  localStorage.setItem(KEY, JSON.stringify(data));
}
