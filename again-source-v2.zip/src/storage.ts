import * as SQLite from "expo-sqlite";
import { Data, emptyData, parseBackup } from "./model";
let db: Promise<SQLite.SQLiteDatabase> | undefined;
async function database() {
  if (!db)
    db = (async () => {
      const conn = await SQLite.openDatabaseAsync("again.db");
      await conn.execAsync(
        "PRAGMA journal_mode = WAL; CREATE TABLE IF NOT EXISTS app_state (id INTEGER PRIMARY KEY CHECK(id = 1), version INTEGER NOT NULL, payload TEXT NOT NULL);",
      );
      return conn;
    })();
  return db;
}
export async function load(): Promise<Data> {
  const conn = await database();
  const row = await conn.getFirstAsync<{ payload: string }>(
    "SELECT payload FROM app_state WHERE id = 1",
  );
  return row ? parseBackup(row.payload) : emptyData();
}
export async function save(data: Data) {
  const conn = await database();
  await conn.runAsync(
    "INSERT INTO app_state(id,version,payload) VALUES(1,1,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,version=excluded.version",
    JSON.stringify(data),
  );
}
