import { Data, parseBackup } from "./model";
export async function exportData(data: Data) {
  const u = URL.createObjectURL(
    new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }),
  );
  const a = document.createElement("a");
  a.href = u;
  a.download = "again-backup.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(u), 1000);
}
export async function importData(): Promise<Data | null> {
  return new Promise((resolve, reject) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json,application/json";
    input.oncancel = () => resolve(null);
    input.onchange = async () => {
      try {
        resolve(
          input.files?.[0] ? parseBackup(await input.files[0].text()) : null,
        );
      } catch (e) {
        reject(e);
      }
    };
    input.click();
  });
}
