import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { AppState } from "react-native";
import { Data, emptyData, today } from "./model";
import * as storage from "./storage";
import { syncReminders } from "./notifications";
type Store = {
  data: Data;
  ready: boolean;
  error: string;
  notice: string;
  setNotice: (s: string) => void;
  commit: (
    next: Data | ((current: Data) => Data),
    label?: string,
  ) => Promise<void>;
  undo: () => void;
  canUndo: boolean;
  day: string;
  reload: () => void;
};
const Context = createContext<Store>(null!);
export function Provider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState(emptyData),
    [ready, setReady] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [backup, setBackup] = useState<Data | null>(null),
    [day, setDay] = useState(today());
  const current = useRef(data);
  const writes = useRef(Promise.resolve());
  async function reload() {
    try {
      const d = await storage.load();
      current.current = d;
      setData(d);
      setReady(true);
      setError("");
      await syncReminders(d);
    } catch (e) {
      setError(
        "Could not load your saved data. Nothing has been overwritten. " +
          String(e),
      );
    }
  }
  useEffect(() => {
    reload();
    const check = () => {
      setDay(today());
      syncReminders(current.current).catch(() =>
        setNotice(
          "Reminders could not be refreshed. Open Settings to check permission.",
        ),
      );
    };
    const sub = AppState.addEventListener("change", (s) => {
      if (s === "active") check();
    });
    const timer = setInterval(() => {
      if (today() !== day) check();
    }, 60000);
    return () => {
      sub.remove();
      clearInterval(timer);
    };
  }, []);
  async function commit(
    input: Data | ((current: Data) => Data),
    label = "Saved",
  ) {
    const operation = writes.current
      .catch(() => {})
      .then(async () => {
        const old = current.current;
        const next = typeof input === "function" ? input(old) : input;
        await storage.save(next);
        current.current = next;
        setBackup(old);
        setData(next);
        setNotice(label);
        try {
          await syncReminders(next);
        } catch {
          setNotice(
            "Saved. Reminders could not be scheduled; check notification settings.",
          );
        }
      });
    writes.current = operation;
    try {
      await operation;
    } catch (e) {
      setNotice("Not saved. Your existing data is safe. " + String(e));
      throw e;
    }
  }
  function undo() {
    if (backup)
      commit(backup, "Undone")
        .then(() => setBackup(null))
        .catch(() => {});
  }
  return (
    <Context.Provider
      value={{
        data,
        ready,
        error,
        notice,
        setNotice,
        commit,
        undo,
        canUndo: !!backup,
        day,
        reload,
      }}
    >
      {children}
    </Context.Provider>
  );
}
export const useStore = () => useContext(Context);
