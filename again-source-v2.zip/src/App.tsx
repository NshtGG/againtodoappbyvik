import React, { useEffect, useMemo, useState } from "react";
import {
  View,
  ScrollView,
  Pressable,
  Modal,
  useWindowDimensions,
  Platform,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Head from "expo-router/head";
import { useStore } from "./provider";
import { useTheme, Txt, Button, Input, Icon, styles } from "./ui";
import { Calendar } from "./Calendar";
import { Editor } from "./Editor";
import {
  Data,
  Task,
  Occurrence,
  Scope,
  occurrences,
  addDays,
  pretty,
  toggle,
  deleteTask,
  repeatLabel,
  emptyData,
  id,
  utc,
  weekday,
} from "./model";
import { permission } from "./notifications";
import { exportData, importData } from "./backup";
const pages = [
  ["Today", "sun"],
  ["Upcoming", "arrow-up-right"],
  ["Calendar", "calendar"],
  ["All tasks", "layers"],
  ["Completed", "check-circle"],
  ["Lists", "grid"],
  ["Settings", "sliders"],
] as const;
export default function App() {
  const store = useStore(),
    { data, day, commit, ready, notice, setNotice } = store,
    c = useTheme(),
    { width } = useWindowDimensions(),
    wide = width >= 1050;
  const [page, setPage] = useState("Today"),
    [search, setSearch] = useState(""),
    [list, setList] = useState("All lists"),
    [priority, setPriority] = useState(-1),
    [status, setStatus] = useState("All"),
    [sort, setSort] = useState("Date"),
    [selected, setSelected] = useState(day),
    [editor, setEditor] = useState<{
      occurrence?: Occurrence;
      initialTitle?: string;
    } | null>(null),
    [quick, setQuick] = useState(""),
    [deleting, setDeleting] = useState<Occurrence | null>(null),
    [confirm, setConfirm] = useState<{
      title: string;
      body: string;
      run: () => void;
    } | null>(null),
    [newList, setNewList] = useState(""),
    [notification, setNotification] = useState("Checking…"),
    [horizon, setHorizon] = useState(30),
    [focus, setFocus] = useState<Occurrence | null>(null),
    [end, setEnd] = useState<number | null>(null),
    [remaining, setRemaining] = useState(data.settings.focusMinutes * 60),
    [running, setRunning] = useState(false);
  const todayRows = useMemo(() => occurrences(data, day, day), [data, day]);
  const done = todayRows.filter((o) => o.completedAt).length;
  const historicalStart = data.tasks.reduce(
    (a, t) => (t.start < a ? t.start : a),
    day,
  );
  const from =
    page === "Today"
      ? day
      : page === "Calendar"
        ? selected
        : page === "Upcoming"
          ? addDays(day, 1)
          : addDays(day, -horizon);
  const to =
    page === "Today"
      ? day
      : page === "Calendar"
        ? selected
        : page === "Completed"
          ? addDays(day, 3650)
          : addDays(day, horizon);
  const raw = useMemo(
    () =>
      page === "Completed"
        ? Object.entries(data.exceptions)
            .filter(([, e]) => e.completedAt && !e.deleted)
            .map(([key, e]) => ({
              key,
              seriesId: key.slice(0, -11),
              date: key.slice(-10),
              task: { ...e.snapshot!, ...e.override },
              completedAt: e.completedAt,
            }))
        : occurrences(data, from, to),
    [data, from, to, page],
  );
  const visible = raw
    .filter(
      (o) =>
        (page !== "Completed" || o.completedAt) &&
        (list === "All lists" || o.task.list === list) &&
        (priority === -1 || o.task.priority === priority) &&
        (status === "All" || (status === "Done") === !!o.completedAt) &&
        `${o.task.title} ${o.task.notes}`
          .toLowerCase()
          .includes(search.toLowerCase()),
    )
    .sort((a, b) =>
      sort === "Priority"
        ? b.task.priority - a.task.priority || a.date.localeCompare(b.date)
        : page === "Completed"
          ? b.completedAt!.localeCompare(a.completedAt!)
          : a.date.localeCompare(b.date) ||
            (a.task.time || "99").localeCompare(b.task.time || "99"),
    );
  const overdue = useMemo(
    () =>
      occurrences(data, addDays(day, -90), addDays(day, -1)).filter(
        (o) => !o.completedAt,
      ),
    [data, day, historicalStart],
  );
  const pending = visible.filter((o) => !o.completedAt),
    completed = visible.filter((o) => o.completedAt);
  const nextTask = [...todayRows.filter((o) => !o.completedAt)].sort(
    (a, b) =>
      b.task.priority - a.task.priority ||
      (a.task.time || "99").localeCompare(b.task.time || "99"),
  )[0];
  useEffect(() => {
    if (Platform.OS === "web" && !__DEV__ && "serviceWorker" in navigator)
      navigator.serviceWorker.register("/sw.js").catch(() => {});
  }, []);
  const perform = (next: Data | ((current: Data) => Data), label?: string) => {
    commit(next, label).catch(() => {});
  };
  useEffect(() => {
    permission()
      .then(setNotification)
      .catch(() => setNotification("Unavailable"));
  }, []);
  useEffect(() => {
    if (!running || !end) return;
    const tick = () => {
      const secs = Math.max(0, Math.ceil((end - Date.now()) / 1000));
      setRemaining(secs);
      if (secs === 0) {
        setRunning(false);
        setEnd(null);
        perform(
          {
            ...data,
            focusSessions: [
              ...data.focusSessions,
              { date: day, minutes: data.settings.focusMinutes },
            ],
          },
          "Focus session complete. Nice work.",
        );
      }
    };
    tick();
    const t = setInterval(tick, 500);
    return () => clearInterval(t);
  }, [running, end, data]);
  function begin(o?: Occurrence) {
    setFocus(o || null);
    setRemaining(data.settings.focusMinutes * 60);
    setEnd(null);
    setRunning(false);
    setPage("Focus");
  }
  function taskRow(o: Occurrence) {
    return (
      <View
        key={o.key}
        style={{
          paddingVertical: 20,
          borderBottomWidth: 1,
          borderColor: c.line,
          flexDirection: "row",
          gap: 14,
          alignItems: "center",
        }}
      >
        <Pressable
          accessibilityRole="checkbox"
          accessibilityState={{ checked: !!o.completedAt }}
          accessibilityLabel={`Complete ${o.task.title} on ${o.date}`}
          onPress={() =>
            perform(
              (current) => toggle(current, o),
              o.completedAt ? "Task reopened" : "One more step, done.",
            )
          }
          style={{
            width: 44,
            height: 44,
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <View
            style={{
              width: 25,
              height: 25,
              borderRadius: 7,
              borderWidth: 1.5,
              borderColor: o.completedAt ? c.ink : c.muted,
              backgroundColor: o.completedAt ? c.ink : "transparent",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            {o.completedAt && <Icon name="check" size={16} color={c.inverse} />}
          </View>
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Edit ${o.task.title}`}
          onPress={() => setEditor({ occurrence: o })}
          style={{ flex: 1, gap: 5 }}
        >
          <Txt
            style={{
              fontSize: 17,
              fontWeight: "600",
              textDecorationLine: o.completedAt ? "line-through" : "none",
              color: o.completedAt ? c.muted : c.ink,
            }}
          >
            {o.task.title}
          </Txt>
          <View style={[styles.wrap, { gap: 10 }]}>
            <Txt style={{ fontSize: 11, color: c.muted }}>{o.task.list}</Txt>
            {o.task.repeat !== "once" && (
              <Txt style={{ fontSize: 11, color: c.muted }}>
                ↻ {repeatLabel(o.task)}
              </Txt>
            )}
            <Txt style={{ fontSize: 11, color: c.muted }}>
              {page === "Today"
                ? o.task.time || "Anytime"
                : `${pretty(o.date, true)}${o.task.time ? " · " + o.task.time : ""}`}
            </Txt>
            {o.task.priority > 0 && (
              <Txt style={{ fontSize: 11, fontWeight: "800" }}>
                {["", "↓ Low", "— Medium", "↑ High"][o.task.priority]}
              </Txt>
            )}
            {o.date < day && !o.completedAt && (
              <Txt style={{ fontSize: 11, fontWeight: "700" }}>Overdue</Txt>
            )}
          </View>
          {o.task.notes && (
            <Txt numberOfLines={1} style={{ fontSize: 12, color: c.muted }}>
              {o.task.notes}
            </Txt>
          )}
        </Pressable>
        {!o.completedAt && wide && (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={`Focus on ${o.task.title}`}
            onPress={() => begin(o)}
            style={{ padding: 12 }}
          >
            <Icon name="play" size={16} />
          </Pressable>
        )}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Delete ${o.task.title}`}
          onPress={() => setDeleting(o)}
          style={{ padding: 12 }}
        >
          <Icon name="more-horizontal" size={19} />
        </Pressable>
      </View>
    );
  }
  function section(label: string, rows: Occurrence[]) {
    return (
      <View style={{ marginTop: 25 }}>
        <View
          style={[
            styles.row,
            {
              justifyContent: "space-between",
              paddingBottom: 12,
              borderBottomWidth: 2,
              borderColor: c.ink,
            },
          ]}
        >
          <Txt style={styles.label}>{label}</Txt>
          <Txt style={[styles.label, { color: c.muted }]}>
            {String(rows.length).padStart(2, "0")}
          </Txt>
        </View>
        {rows.map(taskRow)}
      </View>
    );
  }
  const focusPanel = (
    <View
      style={{ padding: 25, borderRadius: 12, backgroundColor: c.ink, gap: 20 }}
    >
      <View style={[styles.row, { justifyContent: "space-between" }]}>
        <Txt style={[styles.label, { color: c.inverse }]}>
          ONE THING AT A TIME
        </Txt>
        <Icon name="crosshair" color={c.inverse} />
      </View>
      <Txt
        style={{
          fontSize: 30,
          lineHeight: 34,
          fontWeight: "800",
          color: c.inverse,
          letterSpacing: -1,
        }}
      >
        Less noise.{"\n"}More focus.
      </Txt>
      <Txt
        style={{
          fontSize: 12,
          lineHeight: 19,
          color: c.inverse,
          opacity: 0.65,
        }}
      >
        A little uninterrupted time goes a long way.
      </Txt>
      <Button onPress={() => begin(nextTask)} icon="play">
        Start {data.settings.focusMinutes} min session
      </Button>
    </View>
  );
  function nav(name: string, icon: string) {
    return (
      <Pressable
        key={name}
        accessibilityRole="button"
        accessibilityState={{ selected: page === name }}
        onPress={() => {
          setPage(name);
          setList("All lists");
          setSearch("");
        }}
        style={{
          flexDirection: "row",
          gap: 13,
          alignItems: "center",
          paddingVertical: 14,
          paddingHorizontal: 16,
          borderRadius: 8,
          backgroundColor: page === name ? c.ink : "transparent",
          minHeight: 48,
        }}
      >
        <Icon
          name={icon}
          size={18}
          color={page === name ? c.inverse : c.muted}
        />
        <Txt
          style={{
            fontSize: 13,
            fontWeight: page === name ? "800" : "500",
            color: page === name ? c.inverse : c.ink,
          }}
        >
          {name}
        </Txt>
        {name === "Today" && (
          <Txt
            style={{
              marginLeft: "auto",
              fontSize: 11,
              color: page === name ? c.inverse : c.muted,
            }}
          >
            {todayRows.length - done}
          </Txt>
        )}
      </Pressable>
    );
  }
  if (!ready)
    return (
      <SafeAreaView
        style={{
          flex: 1,
          backgroundColor: c.bg,
          justifyContent: "center",
          alignItems: "center",
          padding: 30,
          gap: 20,
        }}
      >
        <Txt style={styles.heading}>again.</Txt>
        <Txt>{store.error || "A little progress, every day."}</Txt>
        {store.error && <Button onPress={store.reload}>Retry loading</Button>}
      </SafeAreaView>
    );
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: c.bg }}>
      <Head>
        <title>Again — make progress repeat</title>
        <meta
          name="description"
          content="An offline task manager built around your rhythm. Flexible recurring tasks, focus sessions, and independent daily progress."
        />
      </Head>
      <View style={{ flex: 1, flexDirection: "row" }}>
        {wide && (
          <View
            style={{
              width: 235,
              borderRightWidth: 1,
              borderColor: c.line,
              padding: 24,
              gap: 24,
            }}
          >
            <View style={{ marginTop: 9, marginBottom: 18 }}>
              <View style={styles.row}>
                <View
                  style={{
                    width: 35,
                    height: 35,
                    backgroundColor: c.ink,
                    borderRadius: 9,
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Icon name="repeat" size={21} color={c.inverse} />
                </View>
                <Txt
                  style={{
                    fontSize: 30,
                    fontWeight: "900",
                    letterSpacing: -1.5,
                  }}
                >
                  again.
                </Txt>
              </View>
              <Txt
                style={{
                  fontSize: 10,
                  letterSpacing: 2,
                  color: c.muted,
                  marginTop: 13,
                }}
              >
                SMALL STEPS. ON REPEAT.
              </Txt>
            </View>
            <View style={{ gap: 4 }}>
              {pages.slice(0, 5).map(([n, i]) => nav(n, i))}
            </View>
            <View style={{ height: 1, backgroundColor: c.line }} />
            <View style={{ gap: 4 }}>
              <Txt
                style={[
                  styles.label,
                  { color: c.muted, paddingLeft: 16, marginBottom: 7 },
                ]}
              >
                YOUR SPACE
              </Txt>
              {pages.slice(5).map(([n, i]) => nav(n, i))}
              {nav("Focus", "crosshair")}
            </View>
            <View style={{ flex: 1 }} />
            <View
              style={{
                borderTopWidth: 1,
                borderColor: c.line,
                paddingTop: 20,
                gap: 4,
              }}
            >
              <Txt style={{ fontWeight: "700", fontSize: 12 }}>
                Yours. Always.
              </Txt>
              <Txt style={{ fontSize: 11, color: c.muted }}>
                Offline. Private. Completely free.
              </Txt>
              <View style={[styles.row, { marginTop: 14 }]}>
                <Icon name="hard-drive" size={13} />
                <Txt style={{ fontSize: 10, color: c.muted }}>
                  SAVED ON THIS DEVICE
                </Txt>
              </View>
            </View>
          </View>
        )}
        <View style={{ flex: 1 }}>
          <View
            style={{
              borderBottomWidth: 1,
              borderColor: c.line,
              paddingHorizontal: wide ? 38 : 20,
              paddingVertical: 16,
              flexDirection: "row",
              gap: 16,
              alignItems: "center",
            }}
          >
            <Txt style={{ fontWeight: "800", fontSize: 13 }}>
              {wide ? "MY WORKSPACE" : "again."}
            </Txt>
            <Txt style={{ color: c.muted, fontSize: 12, marginLeft: "auto" }}>
              {pretty(day, true)} · {utc(day).getUTCFullYear()}
            </Txt>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Toggle dark mode"
              onPress={() =>
                perform(
                  {
                    ...data,
                    settings: {
                      ...data.settings,
                      theme: c.dark ? "light" : "dark",
                    },
                  },
                  "Theme updated",
                )
              }
              style={{ padding: 8 }}
            >
              <Icon name={c.dark ? "sun" : "moon"} size={17} />
            </Pressable>
          </View>
          {!wide && (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={{ flexGrow: 0, maxHeight: 65 }}
              contentContainerStyle={{ padding: 8, gap: 3 }}
            >
              {pages.map(([n, i]) => nav(n, i))}
              {nav("Focus", "crosshair")}
            </ScrollView>
          )}
          <ScrollView
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={{
              padding: wide ? 38 : 20,
              paddingBottom: 80,
            }}
          >
            <View
              style={{ maxWidth: 1250, width: "100%", alignSelf: "center" }}
            >
              <View
                style={[
                  styles.row,
                  {
                    justifyContent: "space-between",
                    marginBottom: 30,
                    alignItems: "flex-end",
                  },
                ]}
              >
                <View style={{ flex: 1 }}>
                  <Txt
                    style={[styles.label, { color: c.muted, marginBottom: 10 }]}
                  >
                    {page === "Today"
                      ? "A FRESH START, EVERY DAY"
                      : page === "Focus"
                        ? "PROTECT YOUR ATTENTION"
                        : "MAKE PROGRESS REPEAT"}
                  </Txt>
                  <Txt
                    accessibilityRole="header"
                    style={[
                      styles.heading,
                      { fontSize: wide ? 58 : 42, lineHeight: wide ? 66 : 49 },
                    ]}
                  >
                    {page === "Today"
                      ? "Make today count."
                      : page === "Upcoming"
                        ? "On the horizon."
                        : page === "Calendar"
                          ? "Find your rhythm."
                          : page === "Completed"
                            ? "Look how far."
                            : page === "All tasks"
                              ? "The bigger picture."
                              : page === "Lists"
                                ? "A place for everything."
                                : page === "Settings"
                                  ? "Make it yours."
                                  : "Just this moment."}
                  </Txt>
                  <Txt style={{ color: c.muted, fontSize: 13, marginTop: 10 }}>
                    {page === "Today"
                      ? `${todayRows.length - done} things to do. One step at a time.`
                      : page === "Upcoming"
                        ? `Your next ${horizon} days, thoughtfully laid out.`
                        : page === "Completed"
                          ? "Every checkmark is a little promise kept."
                          : page === "Calendar"
                            ? "Your schedule, one day at a time."
                            : page === "Settings"
                              ? "Your rhythm. Your preferences. Your data."
                              : page === "Lists"
                                ? "Organize your tasks around the parts of your life."
                                : page === "Focus"
                                  ? "Give one task your undivided attention."
                                  : "One-time tasks and recurring routines, together."}
                  </Txt>
                </View>
                {!["Settings", "Lists", "Focus"].includes(page) && wide && (
                  <Button primary icon="plus" onPress={() => setEditor({})}>
                    New task
                  </Button>
                )}
              </View>
              {!["Settings", "Lists", "Focus"].includes(page) && (
                <View
                  style={{ flexDirection: wide ? "row" : "column", gap: 32 }}
                >
                  <View style={{ flex: 1, minWidth: 0 }}>
                    {page === "Today" && (
                      <View
                        style={{
                          borderWidth: 1,
                          borderColor: c.line,
                          borderRadius: 12,
                          padding: 23,
                          gap: 18,
                          marginBottom: 25,
                          backgroundColor: c.surface,
                        }}
                      >
                        <View
                          style={[
                            styles.row,
                            { justifyContent: "space-between" },
                          ]}
                        >
                          <View>
                            <Txt style={styles.label}>TODAY'S MOMENTUM</Txt>
                            <Txt
                              style={{
                                fontSize: 13,
                                color: c.muted,
                                marginTop: 3,
                              }}
                            >
                              {done === todayRows.length && done
                                ? "Everything done. Take a breath."
                                : "Showing up is where it starts."}
                            </Txt>
                          </View>
                          <Txt
                            style={{
                              fontSize: 34,
                              fontWeight: "900",
                              letterSpacing: -1,
                            }}
                          >
                            {done}
                            <Txt style={{ color: c.muted, fontSize: 18 }}>
                              {" "}
                              / {todayRows.length}
                            </Txt>
                          </Txt>
                        </View>
                        <View
                          style={{
                            height: 5,
                            borderRadius: 3,
                            backgroundColor: c.soft,
                          }}
                        >
                          <View
                            style={{
                              height: 5,
                              width: `${todayRows.length ? (done / todayRows.length) * 100 : 0}%`,
                              backgroundColor: c.ink,
                              borderRadius: 3,
                            }}
                          />
                        </View>
                      </View>
                    )}
                    <View style={[styles.row, { marginBottom: 18 }]}>
                      <View style={{ flex: 1 }}>
                        <Input
                          accessibilityLabel="Quick task title"
                          placeholder="Add a task. Make a little progress…"
                          value={quick}
                          onChangeText={setQuick}
                          onSubmitEditing={() => {
                            if (quick.trim()) {
                              quick.trim()
                                ? perform(
                                    (current) => ({
                                      ...current,
                                      tasks: [
                                        ...current.tasks,
                                        {
                                          id: id(),
                                          title: quick.trim(),
                                          notes: "",
                                          start: day,
                                          time: "",
                                          repeat: "once",
                                          interval: 1,
                                          weekdays: [],
                                          priority: 0,
                                          list: "Personal",
                                          reminder: null,
                                          createdAt: new Date().toISOString(),
                                        },
                                      ],
                                    }),
                                    "Task added",
                                  )
                                : setEditor({});
                              setQuick("");
                            }
                          }}
                        />
                      </View>
                      <Button
                        primary
                        icon="plus"
                        label="Add task"
                        onPress={() => {
                          quick.trim()
                            ? perform(
                                (current) => ({
                                  ...current,
                                  tasks: [
                                    ...current.tasks,
                                    {
                                      id: id(),
                                      title: quick.trim(),
                                      notes: "",
                                      start: day,
                                      time: "",
                                      repeat: "once",
                                      interval: 1,
                                      weekdays: [],
                                      priority: 0,
                                      list: "Personal",
                                      reminder: null,
                                      createdAt: new Date().toISOString(),
                                    },
                                  ],
                                }),
                                "Task added",
                              )
                            : setEditor({});
                          setQuick("");
                        }}
                      >
                        Add
                      </Button>
                    </View>
                    <Input
                      label="SEARCH YOUR TASKS"
                      placeholder="Search titles and notes"
                      value={search}
                      onChangeText={setSearch}
                    />
                    <View style={[styles.wrap, { marginTop: 14 }]}>
                      <Button
                        small
                        onPress={() =>
                          setList(
                            data.lists.concat("All lists")[
                              (data.lists.concat("All lists").indexOf(list) +
                                1) %
                                (data.lists.length + 1)
                            ],
                          )
                        }
                      >
                        {list} ▾
                      </Button>
                      <Button
                        small
                        onPress={() =>
                          setPriority(priority === 3 ? -1 : priority + 1)
                        }
                      >
                        {priority === -1
                          ? "Any priority"
                          : ["No priority", "Low", "Medium", "High"][
                              priority
                            ]}{" "}
                        ▾
                      </Button>
                      <Button
                        small
                        onPress={() =>
                          setStatus(
                            ["All", "Pending", "Done"][
                              (["All", "Pending", "Done"].indexOf(status) + 1) %
                                3
                            ],
                          )
                        }
                      >
                        {status} ▾
                      </Button>
                      <Button
                        small
                        onPress={() =>
                          setSort(sort === "Date" ? "Priority" : "Date")
                        }
                      >
                        Sort: {sort} ↕
                      </Button>
                    </View>
                    {page === "Calendar" && (
                      <View style={{ marginTop: 25, maxWidth: 500 }}>
                        <Calendar
                          value={selected}
                          onChange={setSelected}
                          counts={Object.fromEntries(
                            occurrences(
                              data,
                              addDays(selected, -45),
                              addDays(selected, 45),
                            ).map((o) => [o.date, 1]),
                          )}
                        />
                        <Txt style={{ fontWeight: "800", marginTop: 20 }}>
                          {pretty(selected)}
                        </Txt>
                      </View>
                    )}
                    {page === "Completed" ? (
                      section("COMPLETED HISTORY", visible)
                    ) : (
                      <>
                        {pending.length > 0 &&
                          section(
                            page === "Today" ? "UP NEXT" : "TO DO",
                            pending,
                          )}
                        {completed.length > 0 &&
                          section("DONE & DUSTED", completed)}
                      </>
                    )}
                    {visible.length === 0 && (
                      <View
                        style={{
                          paddingVertical: 45,
                          gap: 14,
                          alignItems: "center",
                          borderBottomWidth: 1,
                          borderColor: c.line,
                        }}
                      >
                        <Icon
                          name={search ? "search" : "check-circle"}
                          size={32}
                        />
                        <Txt style={{ fontWeight: "800", fontSize: 19 }}>
                          {search
                            ? "No matching tasks."
                            : page === "Completed"
                              ? "Your progress starts here."
                              : "A little room to breathe."}
                        </Txt>
                        <Txt
                          style={{
                            fontSize: 13,
                            color: c.muted,
                            textAlign: "center",
                          }}
                        >
                          {page === "Completed"
                            ? "Complete a task to start your history."
                            : "Add something that matters. We’ll take care of the repeat."}
                        </Txt>
                        <Button small onPress={() => setEditor({})}>
                          Create a task
                        </Button>
                      </View>
                    )}
                    {page === "Today" &&
                      overdue.length > 0 &&
                      section(
                        `OVERDUE · PAST 90 DAYS · ${overdue.length} TOTAL`,
                        overdue.slice(-20),
                      )}
                    {["Upcoming", "All tasks"].includes(page) && (
                      <Button
                        style={{ marginTop: 25 }}
                        onPress={() => setHorizon(horizon + 30)}
                      >
                        Expand date window by 30 days
                      </Button>
                    )}
                  </View>
                  {wide && (
                    <View style={{ width: 280, gap: 23 }}>
                      {focusPanel}
                      <View
                        style={[
                          styles.card,
                          { backgroundColor: c.surface, borderColor: c.line },
                        ]}
                      >
                        <Txt style={styles.label}>YOUR NEXT BEST STEP</Txt>
                        <Txt
                          style={{
                            fontSize: 20,
                            fontWeight: "800",
                            lineHeight: 26,
                          }}
                        >
                          {nextTask?.task.title || "Choose your first step."}
                        </Txt>
                        <Txt style={{ color: c.muted, fontSize: 12 }}>
                          {nextTask
                            ? "Picked by priority, then time. You decide when."
                            : "Add a task to give your day a little direction."}
                        </Txt>
                        <Button
                          small
                          onPress={() =>
                            nextTask ? begin(nextTask) : setEditor({})
                          }
                        >
                          {nextTask ? "Give it your focus ↗" : "Add a task ↗"}
                        </Button>
                      </View>
                      <View style={{ padding: 10, gap: 12 }}>
                        <Txt style={styles.label}>THE AGAIN APPROACH</Txt>
                        <Txt
                          style={{
                            fontSize: 22,
                            fontWeight: "700",
                            lineHeight: 29,
                            letterSpacing: -0.5,
                          }}
                        >
                          You don’t need a perfect day. Just a next step.
                        </Txt>
                        <View
                          style={{
                            height: 2,
                            width: 32,
                            backgroundColor: c.ink,
                          }}
                        />
                        <Txt style={{ fontSize: 11, color: c.muted }}>
                          REPEAT THE GOOD THINGS.
                        </Txt>
                      </View>
                    </View>
                  )}
                </View>
              )}
              {page === "Lists" && (
                <View style={{ gap: 25 }}>
                  <View style={styles.row}>
                    <View style={{ flex: 1 }}>
                      <Input
                        label="NEW LIST"
                        placeholder="A new part of your life"
                        value={newList}
                        onChangeText={setNewList}
                      />
                    </View>
                    <Button
                      primary
                      onPress={() => {
                        const name = newList.trim();
                        if (
                          name &&
                          name.length < 100 &&
                          !data.lists.includes(name)
                        ) {
                          perform(
                            { ...data, lists: [...data.lists, name] },
                            "List added",
                          );
                          setNewList("");
                        }
                      }}
                    >
                      Create
                    </Button>
                  </View>
                  <View style={styles.wrap}>
                    {data.lists.map((l) => (
                      <Pressable
                        accessibilityRole="button"
                        key={l}
                        onPress={() => {
                          setList(l);
                          setPage("All tasks");
                        }}
                        style={{
                          width: wide ? "31%" : "100%",
                          padding: 25,
                          borderWidth: 1,
                          borderColor: c.line,
                          borderRadius: 12,
                          backgroundColor: c.surface,
                          gap: 15,
                        }}
                      >
                        <Icon name="folder" />
                        <Txt style={{ fontSize: 23, fontWeight: "800" }}>
                          {l}
                        </Txt>
                        <Txt style={{ fontSize: 12, color: c.muted }}>
                          {
                            data.tasks.filter(
                              (t) => t.list === l && !t.archived,
                            ).length
                          }{" "}
                          tasks & routines ↗
                        </Txt>
                      </Pressable>
                    ))}
                  </View>
                </View>
              )}
              {page === "Focus" && (
                <View
                  style={{
                    maxWidth: 700,
                    alignSelf: "center",
                    width: "100%",
                    gap: 26,
                  }}
                >
                  <View
                    style={[
                      styles.card,
                      {
                        borderColor: c.line,
                        backgroundColor: c.surface,
                        alignItems: "center",
                        paddingVertical: 45,
                      },
                    ]}
                  >
                    <Txt style={styles.label}>
                      {focus?.task.title || "OPEN FOCUS SESSION"}
                    </Txt>
                    <Txt
                      style={{
                        fontSize: width < 500 ? 78 : 110,
                        lineHeight: 130,
                        fontWeight: "900",
                        letterSpacing: -6,
                        fontVariant: ["tabular-nums"],
                      }}
                    >
                      {String(Math.floor(remaining / 60)).padStart(2, "0")}:
                      {String(remaining % 60).padStart(2, "0")}
                    </Txt>
                    <View style={styles.wrap}>
                      <Button
                        primary
                        icon={running ? "pause" : "play"}
                        onPress={() => {
                          if (running) {
                            setRunning(false);
                            setEnd(null);
                          } else {
                            const seconds =
                              remaining || data.settings.focusMinutes * 60;
                            setRemaining(seconds);
                            setEnd(Date.now() + seconds * 1000);
                            setRunning(true);
                          }
                        }}
                      >
                        {running ? "Pause" : "Start focus"}
                      </Button>
                      <Button
                        onPress={() => {
                          setRunning(false);
                          setEnd(null);
                          setRemaining(data.settings.focusMinutes * 60);
                        }}
                      >
                        Reset
                      </Button>
                      {focus && (
                        <Button
                          onPress={() => {
                            perform(
                              toggle(data, {
                                ...focus,
                                completedAt:
                                  data.exceptions[focus.key]?.completedAt,
                              }),
                              "Task updated",
                            );
                            setFocus(null);
                            setRunning(false);
                          }}
                        >
                          Mark task done
                        </Button>
                      )}
                    </View>
                    <Txt
                      style={{
                        color: c.muted,
                        fontSize: 12,
                        textAlign: "center",
                      }}
                    >
                      Keep this screen available. The timer catches up when you
                      return.
                    </Txt>
                  </View>
                  <View style={styles.wrap}>
                    {[15, 25, 45, 60].map((n) => (
                      <Button
                        key={n}
                        primary={data.settings.focusMinutes === n}
                        disabled={running}
                        onPress={() => {
                          perform(
                            {
                              ...data,
                              settings: { ...data.settings, focusMinutes: n },
                            },
                            "Focus duration updated",
                          );
                          setRemaining(n * 60);
                        }}
                      >
                        {n} minutes
                      </Button>
                    ))}
                  </View>
                  <Txt style={{ fontWeight: "700" }}>
                    {data.focusSessions
                      .filter((s) => s.date === day)
                      .reduce((a, s) => a + s.minutes, 0)}{" "}
                    focused minutes today
                  </Txt>
                </View>
              )}
              {page === "Settings" && (
                <View style={{ maxWidth: 750, gap: 25 }}>
                  <View
                    style={[
                      styles.card,
                      { borderColor: c.line, backgroundColor: c.surface },
                    ]}
                  >
                    <Txt style={styles.label}>APPEARANCE</Txt>
                    <View style={styles.wrap}>
                      {(["system", "light", "dark"] as const).map((theme) => (
                        <Button
                          key={theme}
                          primary={data.settings.theme === theme}
                          onPress={() =>
                            perform(
                              {
                                ...data,
                                settings: { ...data.settings, theme },
                              },
                              "Theme updated",
                            )
                          }
                        >
                          {theme[0].toUpperCase() + theme.slice(1)}
                        </Button>
                      ))}
                    </View>
                    <Txt style={styles.label}>WEEK STARTS ON</Txt>
                    <View style={styles.wrap}>
                      {([1, 0] as const).map((n) => (
                        <Button
                          key={n}
                          primary={data.settings.weekStart === n}
                          onPress={() =>
                            perform(
                              {
                                ...data,
                                settings: { ...data.settings, weekStart: n },
                              },
                              "Calendar updated",
                            )
                          }
                        >
                          {n ? "Monday" : "Sunday"}
                        </Button>
                      ))}
                    </View>
                  </View>
                  <View
                    style={[
                      styles.card,
                      { borderColor: c.line, backgroundColor: c.surface },
                    ]}
                  >
                    <Txt style={styles.label}>REMINDERS</Txt>
                    <Txt>Permission: {notification}</Txt>
                    <Txt style={{ fontSize: 12, color: c.muted }}>
                      Device reminders cover the next 60 scheduled occurrences
                      within 60 days. Open Again regularly to refresh them.
                      Times follow your device’s local timezone on refresh.
                    </Txt>
                    <Button
                      primary
                      onPress={async () => {
                        try {
                          if (data.settings.notifications) {
                            perform(
                              {
                                ...data,
                                settings: {
                                  ...data.settings,
                                  notifications: false,
                                },
                              },
                              "Reminders disabled",
                            );
                          } else {
                            const p = await permission(true);
                            setNotification(p);
                            if (p === "granted")
                              perform(
                                {
                                  ...data,
                                  settings: {
                                    ...data.settings,
                                    notifications: true,
                                  },
                                },
                                "Reminders enabled",
                              );
                            else
                              setNotice(
                                Platform.OS === "web"
                                  ? "Background reminders are available in the Android and iOS apps."
                                  : "Permission denied. You can enable notifications in your device settings.",
                              );
                          }
                        } catch {
                          setNotice(
                            "Notification permission could not be checked.",
                          );
                        }
                      }}
                    >
                      {data.settings.notifications
                        ? "Disable reminders"
                        : "Enable reminders"}
                    </Button>
                    <Txt style={styles.label}>
                      DEFAULT REMINDER FOR NEW TIMED TASKS
                    </Txt>
                    <View style={styles.wrap}>
                      {[null, 0, 5, 15, 60].map((n) => (
                        <Button
                          small
                          key={String(n)}
                          primary={data.settings.defaultReminder === n}
                          onPress={() =>
                            perform(
                              {
                                ...data,
                                settings: {
                                  ...data.settings,
                                  defaultReminder: n,
                                },
                              },
                              "Default updated",
                            )
                          }
                        >
                          {n === null
                            ? "Off"
                            : n === 0
                              ? "At time"
                              : `${n}m before`}
                        </Button>
                      ))}
                    </View>
                  </View>
                  <View
                    style={[
                      styles.card,
                      { borderColor: c.line, backgroundColor: c.surface },
                    ]}
                  >
                    <Txt style={styles.label}>YOUR DATA, YOURS TO KEEP</Txt>
                    <Txt style={{ fontSize: 13, color: c.muted }}>
                      Tasks stay on this device. Export a backup to move them or
                      keep a safe copy. Import replaces the current workspace
                      after confirmation.
                    </Txt>
                    <View style={styles.wrap}>
                      <Button
                        icon="download"
                        onPress={() =>
                          exportData(data).catch((e) => setNotice(String(e)))
                        }
                      >
                        Export backup
                      </Button>
                      <Button
                        icon="upload"
                        onPress={async () => {
                          try {
                            const imported = await importData();
                            if (imported)
                              setConfirm({
                                title: "Replace your workspace?",
                                body: `Import ${imported.tasks.length} tasks and their history. Your current data will be replaced.`,
                                run: () => perform(imported, "Backup imported"),
                              });
                          } catch (e) {
                            setNotice("Import failed: " + String(e));
                          }
                        }}
                      >
                        Import backup
                      </Button>
                    </View>
                    <Button
                      onPress={() =>
                        setConfirm({
                          title: "Delete all local data?",
                          body: "This removes every task, list, completion and focus session on this device. Export a backup first if you want to keep them.",
                          run: () => perform(emptyData(), "Workspace cleared"),
                        })
                      }
                    >
                      Delete all local data
                    </Button>
                  </View>
                  <Txt style={{ color: c.muted, fontSize: 12 }}>
                    Again 1.0.0 · Made for small steps. No ads, accounts, or
                    paywalls.
                  </Txt>
                </View>
              )}
            </View>
          </ScrollView>
          {notice && (
            <View
              style={{
                position: "absolute",
                bottom: 18,
                left: 18,
                right: 18,
                backgroundColor: c.ink,
                padding: 16,
                borderRadius: 10,
                flexDirection: "row",
                alignItems: "center",
                gap: 15,
              }}
            >
              <Txt
                accessibilityRole="alert"
                style={{ flex: 1, color: c.inverse, fontSize: 12 }}
              >
                {notice}
              </Txt>
              {store.canUndo && (
                <Pressable
                  accessibilityRole="button"
                  onPress={store.undo}
                  style={{ padding: 8 }}
                >
                  <Txt
                    style={{
                      color: c.inverse,
                      fontWeight: "800",
                      fontSize: 12,
                    }}
                  >
                    Undo
                  </Txt>
                </Pressable>
              )}
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Dismiss notification"
                onPress={() => setNotice("")}
                style={{ padding: 8 }}
              >
                <Icon name="x" color={c.inverse} size={16} />
              </Pressable>
            </View>
          )}
        </View>
      </View>
      {editor && <Editor {...editor} onClose={() => setEditor(null)} />}
      {(deleting || confirm) && (
        <Modal
          transparent
          animationType="fade"
          onRequestClose={() => {
            setDeleting(null);
            setConfirm(null);
          }}
        >
          <View
            style={{
              flex: 1,
              backgroundColor: "#0009",
              justifyContent: "center",
              alignItems: "center",
              padding: 25,
            }}
          >
            <View
              style={{
                width: "100%",
                maxWidth: 450,
                backgroundColor: c.bg,
                borderRadius: 14,
                padding: 28,
                gap: 20,
              }}
            >
              <Txt style={{ fontSize: 25, fontWeight: "900" }}>
                {deleting ? "Delete this task?" : confirm?.title}
              </Txt>
              <Txt style={{ fontSize: 13, color: c.muted }}>
                {deleting
                  ? `${deleting.task.title}. Completed history is preserved when deleting a series.`
                  : confirm?.body}
              </Txt>
              {deleting ? (
                <>
                  {(
                    [
                      "one",
                      ...(deleting.task.repeat !== "once"
                        ? ["future", "all"]
                        : []),
                    ] as Scope[]
                  ).map((s) => (
                    <Button
                      key={s}
                      onPress={() => {
                        perform(
                          (current) => deleteTask(current, deleting, s),
                          "Task deleted",
                        );
                        setDeleting(null);
                      }}
                    >
                      {s === "one"
                        ? "This occurrence"
                        : s === "future"
                          ? "This and future occurrences"
                          : "Entire series"}
                    </Button>
                  ))}
                </>
              ) : (
                <Button
                  primary
                  onPress={() => {
                    confirm?.run();
                    setConfirm(null);
                  }}
                >
                  Confirm
                </Button>
              )}
              <Button
                onPress={() => {
                  setDeleting(null);
                  setConfirm(null);
                }}
              >
                Cancel
              </Button>
            </View>
          </View>
        </Modal>
      )}
    </SafeAreaView>
  );
}
