import React, { useState } from "react";
import { View, Pressable } from "react-native";
import { addDays, utc, weekday, today, Day } from "./model";
import { Button, Txt, useTheme, styles } from "./ui";
import { useStore } from "./provider";
export function Calendar({
  value,
  onChange,
  counts = {},
}: {
  value: Day;
  onChange: (d: Day) => void;
  counts?: Record<string, number>;
}) {
  const { data } = useStore(),
    c = useTheme();
  const [month, setMonth] = useState(value.slice(0, 7) + "-01");
  const shift = (n: number) => {
    const d = utc(month);
    d.setUTCMonth(d.getUTCMonth() + n);
    setMonth(d.toISOString().slice(0, 10));
  };
  const start = addDays(
    month,
    -((weekday(month) - data.settings.weekStart + 7) % 7),
  );
  return (
    <View style={{ gap: 13 }}>
      <View style={[styles.row, { justifyContent: "space-between" }]}>
        <Txt style={{ fontSize: 17, fontWeight: "800" }}>
          {utc(month).toLocaleDateString("en-US", {
            month: "long",
            year: "numeric",
            timeZone: "UTC",
          })}
        </Txt>
        <View style={styles.row}>
          <Button small onPress={() => shift(-1)} label="Previous month">
            ‹
          </Button>
          <Button small onPress={() => shift(1)} label="Next month">
            ›
          </Button>
        </View>
      </View>
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
        {Array.from({ length: 7 }, (_, i) => (
          <View
            key={i}
            style={{ width: "14.285%", alignItems: "center", paddingBottom: 9 }}
          >
            <Txt style={{ fontSize: 10, color: c.muted }}>
              {
                ["S", "M", "T", "W", "T", "F", "S"][
                  (i + data.settings.weekStart) % 7
                ]
              }
            </Txt>
          </View>
        ))}
        {Array.from({ length: 42 }, (_, i) => {
          const d = addDays(start, i),
            selected = d === value;
          return (
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={d}
              accessibilityState={{ selected }}
              key={d}
              onPress={() => onChange(d)}
              style={{
                width: "14.285%",
                minHeight: 44,
                paddingVertical: 8,
                alignItems: "center",
                backgroundColor: selected ? c.ink : "transparent",
                borderRadius: 7,
                opacity: d.slice(0, 7) === month.slice(0, 7) ? 1 : 0.35,
              }}
            >
              <Txt
                style={{
                  color: selected ? c.inverse : c.ink,
                  fontWeight: d === today() ? "900" : "500",
                  fontSize: 13,
                }}
              >
                {Number(d.slice(-2))}
              </Txt>
              <View
                style={{
                  width: 3,
                  height: 3,
                  borderRadius: 2,
                  backgroundColor: counts[d]
                    ? selected
                      ? c.inverse
                      : c.ink
                    : "transparent",
                }}
              />
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}
