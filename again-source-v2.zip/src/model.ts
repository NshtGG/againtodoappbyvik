export type Day = string;
export type Repeat =
  | "once"
  | "daily"
  | "weekdays"
  | "weekly"
  | "selected"
  | "monthly"
  | "intervalDays"
  | "intervalWeeks";
export type Priority = 0 | 1 | 2 | 3;
export type Ringtone = "gentle" | "bright" | "focus" | "silent";
export interface ChecklistItem {
  id: string;
  text: string;
  done: boolean;
}
export interface Task {
  id: string;
  title: string;
  notes: string;
  start: Day;
  end?: Day;
  time: string;
  repeat: Repeat;
  interval: number;
  weekdays: number[];
  priority: Priority;
  list: string;
  reminder: number | null;
  ringtone?: Ringtone;
  checklist?: ChecklistItem[];
  createdAt: string;
  archived?: boolean;
}
export interface Occurrence {
  key: string;
  seriesId: string;
  date: Day;
  task: Task;
  completedAt?: string;
  skipped?: boolean;
}
export interface Exception {
  completedAt?: string;
  deleted?: boolean;
  override?: Partial<Task>;
  snapshot?: Task;
}
export type Theme = "system" | "light" | "dark" | "rose" | "ocean" | "forest";
export interface Settings {
  theme: Theme;
  weekStart: 0 | 1;
  defaultReminder: number | null;
  notifications: boolean;
  focusMinutes: number;
  completionSound?: boolean;
}
export interface Data {
  version: 1;
  tasks: Task[];
  exceptions: Record<string, Exception>;
  lists: string[];
  settings: Settings;
  focusSessions: { date: Day; minutes: number }[];
}
export const emptyData = (): Data => ({
  version: 1,
  tasks: [],
  exceptions: {},
  lists: ["Personal", "Work", "Study", "Health"],
  settings: {
    theme: "system",
    weekStart: 1,
    defaultReminder: null,
    notifications: false,
    focusMinutes: 25,
    completionSound: true,
  },
  focusSessions: [],
});
export const id = () =>
  `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
export const today = (): Day => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
export function validDay(s: unknown): s is Day {
  if (typeof s !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(s + "T12:00:00Z");
  return Number.isFinite(+d) && d.toISOString().slice(0, 10) === s;
}
export const utc = (d: Day) => new Date(d + "T12:00:00Z");
export const dayNumber = (d: Day) => Math.floor(+utc(d) / 86400000);
export const addDays = (d: Day, n: number): Day =>
  new Date(+utc(d) + n * 86400000).toISOString().slice(0, 10);
export const weekday = (d: Day) => utc(d).getUTCDay();
export const pretty = (d: Day, short = false) =>
  utc(d).toLocaleDateString("en-US", {
    timeZone: "UTC",
    month: short ? "short" : "long",
    day: "numeric",
    ...(short ? {} : { weekday: "long" }),
  });
export function matches(t: Task, date: Day): boolean {
  if (t.archived || date < t.start || (t.end && date > t.end)) return false;
  const diff = dayNumber(date) - dayNumber(t.start);
  switch (t.repeat) {
    case "once":
      return diff === 0;
    case "daily":
      return true;
    case "weekdays":
      return weekday(date) > 0 && weekday(date) < 6;
    case "weekly":
      return weekday(date) === weekday(t.start);
    case "selected":
      return t.weekdays.includes(weekday(date));
    case "intervalDays":
      return diff % t.interval === 0;
    case "intervalWeeks":
      return diff % (7 * t.interval) === 0;
    case "monthly": {
      const x = utc(date),
        s = utc(t.start);
      const last = new Date(
        Date.UTC(x.getUTCFullYear(), x.getUTCMonth() + 1, 0),
      ).getUTCDate();
      return x.getUTCDate() === Math.min(s.getUTCDate(), last);
    }
  }
}
export function dates(t: Task, from: Day, to: Day): Day[] {
  const result: Day[] = [];
  for (let d = from > t.start ? from : t.start; d <= to; d = addDays(d, 1)) {
    if (t.end && d > t.end) break;
    if (matches(t, d)) result.push(d);
  }
  return result;
}
export function occurrences(data: Data, from: Day, to: Day): Occurrence[] {
  const out = new Map<string, Occurrence>();
  for (const task of data.tasks) {
    for (const date of dates(task, from, to)) {
      const key = task.id + ":" + date,
        e = data.exceptions[key];
      if (!e?.deleted)
        out.set(key, {
          key,
          seriesId: task.id,
          date,
          task: { ...(e?.snapshot || task), ...e?.override },
          completedAt: e?.completedAt,
        });
    }
  }
  // Completion snapshots survive a changed rule or an archived series.
  for (const [key, e] of Object.entries(data.exceptions)) {
    const date = key.slice(-10);
    if (e.completedAt && e.snapshot && !e.deleted && date >= from && date <= to)
      out.set(key, {
        key,
        seriesId: key.slice(0, -11),
        date,
        task: { ...e.snapshot, ...e.override },
        completedAt: e.completedAt,
      });
  }
  return [...out.values()].sort(
    (a, b) =>
      a.date.localeCompare(b.date) ||
      (a.task.time || "99").localeCompare(b.task.time || "99") ||
      b.task.priority - a.task.priority,
  );
}
export function toggle(data: Data, o: Occurrence): Data {
  const next = JSON.parse(JSON.stringify(data)) as Data,
    e = next.exceptions[o.key] || {};
  if (e.completedAt) {
    delete e.completedAt;
    delete e.snapshot;
  } else {
    e.completedAt = new Date().toISOString();
    e.snapshot = o.task;
  }
  next.exceptions[o.key] = e;
  return next;
}
export type Scope = "one" | "future" | "all";
export function editTask(
  data: Data,
  o: Occurrence,
  replacement: Task,
  scope: Scope,
): Data {
  const next = JSON.parse(JSON.stringify(data)) as Data;
  const original = next.tasks.find((t) => t.id === o.seriesId)!;
  if (scope === "one") {
    next.exceptions[o.key] = {
      ...next.exceptions[o.key],
      override: { ...replacement, start: o.date },
      ...(o.completedAt ? { snapshot: replacement } : {}),
    };
    return next;
  }
  if (scope === "future") {
    const newId = id();
    original.end = addDays(o.date, -1);
    next.tasks.push({
      ...replacement,
      id: newId,
      start: o.date,
      createdAt: new Date().toISOString(),
      archived: false,
    });
    for (const [key, e] of Object.entries(next.exceptions)) {
      if (key.startsWith(o.seriesId + ":") && key.slice(-10) >= o.date) {
        if (e.completedAt) next.exceptions[newId + ":" + key.slice(-10)] = e;
        delete next.exceptions[key];
      }
    }
  } else {
    next.tasks = next.tasks.map((t) =>
      t.id === o.seriesId
        ? { ...replacement, id: t.id, createdAt: t.createdAt }
        : t,
    );
  }
  return next;
}
export function deleteTask(data: Data, o: Occurrence, scope: Scope): Data {
  const next = JSON.parse(JSON.stringify(data)) as Data;
  if (scope === "one") {
    next.exceptions[o.key] = { ...next.exceptions[o.key], deleted: true };
  } else if (scope === "future") {
    next.tasks = next.tasks.map((t) =>
      t.id === o.seriesId ? { ...t, end: addDays(o.date, -1) } : t,
    );
  } else {
    next.tasks = next.tasks.map((t) =>
      t.id === o.seriesId ? { ...t, archived: true } : t,
    );
  }
  return next;
}
export const repeatLabel = (t: Task) =>
  ({
    once: "One time",
    daily: "Every day",
    weekdays: "Weekdays",
    weekly: "Every week",
    selected: t.weekdays
      .map((d) => ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][d])
      .join(", "),
    monthly: "Every month",
    intervalDays: `Every ${t.interval} days`,
    intervalWeeks: `Every ${t.interval} weeks`,
  })[t.repeat];
export function validateTask(t: Task): string | null {
  if (!t.title.trim()) return "Give your task a title.";
  if (t.title.length > 250 || t.notes.length > 10000)
    return "Please shorten the title or notes.";
  if (!validDay(t.start) || (t.end && !validDay(t.end)))
    return "Choose a valid date.";
  if (t.end && t.end < t.start)
    return "End date must be on or after the start date.";
  if (t.repeat === "selected" && !t.weekdays.length)
    return "Choose at least one weekday.";
  if (!Number.isInteger(t.interval) || t.interval < 1 || t.interval > 365)
    return "Interval must be between 1 and 365.";
  if (t.time && !/^([01]\d|2[0-3]):[0-5]\d$/.test(t.time))
    return "Use a 24-hour time, like 09:30.";
  if (t.reminder !== null && !t.time) return "Add a time for your reminder.";
  if ((t.checklist || []).some((item) => !item.text.trim() || item.text.length > 200))
    return "Checklist items need a short name.";
  return null;
}
export function parseBackup(text: string): Data {
  if (text.length > 10000000) throw new Error("Backup exceeds 10 MB.");
  const d = JSON.parse(text);
  if (
    d.version !== 1 ||
    !Array.isArray(d.tasks) ||
    !d.exceptions ||
    Array.isArray(d.exceptions) ||
    !Array.isArray(d.lists) ||
    !d.settings ||
    !Array.isArray(d.focusSessions)
  )
    throw new Error("This is not an Again backup.");
  const modes = [
    "once",
    "daily",
    "weekdays",
    "weekly",
    "selected",
    "monthly",
    "intervalDays",
    "intervalWeeks",
  ];
  const taskOK = (t: any) =>
    t &&
    typeof t.id === "string" &&
    typeof t.title === "string" &&
    typeof t.notes === "string" &&
    typeof t.time === "string" &&
    typeof t.list === "string" &&
    typeof t.createdAt === "string" &&
    modes.includes(t.repeat) &&
    [0, 1, 2, 3].includes(t.priority) &&
    Array.isArray(t.weekdays) &&
    t.weekdays.every((n: any) => Number.isInteger(n) && n >= 0 && n <= 6) &&
    [null, 0, 5, 15, 30, 60, 1440, 2880].includes(t.reminder) &&
    (!t.ringtone || ["gentle", "bright", "focus", "silent"].includes(t.ringtone)) &&
    (!t.checklist || (Array.isArray(t.checklist) && t.checklist.every((i: any) =>
      i && typeof i.id === "string" && typeof i.text === "string" && typeof i.done === "boolean"))) &&
    !validateTask(t);
  if (
    d.tasks.length > 10000 ||
    !d.tasks.every(taskOK) ||
    new Set(d.tasks.map((t: Task) => t.id)).size !== d.tasks.length ||
    !d.lists.every((s: any) => typeof s === "string" && s.length < 100)
  )
    throw new Error("Backup contains invalid tasks or lists.");
  for (const [k, e] of Object.entries(d.exceptions) as [string, any][]) {
    if (
      !validDay(k.slice(-10)) ||
      !e ||
      typeof e !== "object" ||
      (e.snapshot && !taskOK(e.snapshot)) ||
      (e.override &&
        !taskOK({
          ...d.tasks.find((t: Task) => t.id === k.slice(0, -11)),
          ...e.override,
        })) ||
      (e.completedAt && !Number.isFinite(Date.parse(e.completedAt)))
    )
      throw new Error("Backup contains invalid history.");
  }
  if (
    !["system", "light", "dark", "rose", "ocean", "forest"].includes(d.settings.theme) ||
    ![0, 1].includes(d.settings.weekStart) ||
    ![null, 0, 5, 15, 30, 60, 1440, 2880].includes(d.settings.defaultReminder) ||
    typeof d.settings.notifications !== "boolean" ||
    !Number.isInteger(d.settings.focusMinutes) ||
    d.settings.focusMinutes < 1 ||
    d.settings.focusMinutes > 120 ||
    !d.focusSessions.every(
      (s: any) =>
        validDay(s.date) && Number.isFinite(s.minutes) && s.minutes > 0,
    )
  )
    throw new Error("Backup contains invalid settings.");
  d.settings.completionSound ??= true;
  return d;
}
