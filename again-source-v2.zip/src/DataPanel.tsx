import React from 'react';
import {View} from 'react-native';
import {useStore} from './provider';
import {Txt,Button,Icon,useTheme,styles} from './ui';
import {occurrences,addDays,utc} from './model';
export function DataPanel({open}:{open:(page:string)=>void}){
 const {data,day}=useStore(),c=useTheme();
 const days=Array.from({length:7},(_,i)=>addDays(day,i-6));
 const rows=occurrences(data,days[0],day);
 const completed=rows.filter(o=>o.completedAt).length;
 const rate=rows.length?Math.round(completed/rows.length*100):0;
 const history=Object.values(data.exceptions).filter(e=>e.completedAt&&!e.deleted).length;
 const bars=days.map(date=>({date,done:rows.filter(o=>o.date===date&&o.completedAt).length,total:rows.filter(o=>o.date===date).length}));
 const maximum=Math.max(1,...bars.map(b=>b.total));
 const minutes=data.focusSessions.filter(s=>s.date>=days[0]&&s.date<=day).reduce((a,s)=>a+s.minutes,0);
 return <View style={{gap:22}}>
  <View style={{backgroundColor:c.ink,padding:24,borderRadius:22,gap:10}}><Txt style={[styles.label,{color:c.inverse,opacity:.7}]}>YOUR LAST 7 DAYS</Txt><View style={[styles.row,{alignItems:'flex-end',justifyContent:'space-between'}]}><Txt style={{fontSize:64,lineHeight:70,fontWeight:'900',letterSpacing:-4,color:c.inverse}}>{rate}%</Txt><Icon name="trending-up" color={c.inverse} size={32}/></View><Txt style={{color:c.inverse,fontSize:13}}>{completed} of {rows.length} scheduled tasks completed</Txt><View style={{height:5,backgroundColor:c.muted,borderRadius:5,marginTop:8}}><View style={{height:5,width:`${rate}%`,backgroundColor:c.inverse,borderRadius:5}}/></View></View>
  <View style={{flexDirection:'row',gap:12}}>{[[String(history),'ALL-TIME DONE','check-circle'],[String(minutes),'FOCUS MINUTES','clock']].map(([value,label,icon])=><View key={label} style={{flex:1,padding:18,borderWidth:1,borderColor:c.line,backgroundColor:c.surface,borderRadius:16,gap:8}}><Icon name={icon} size={18}/><Txt style={{fontSize:30,lineHeight:36,fontWeight:'900'}}>{value}</Txt><Txt style={{fontSize:9,fontWeight:'800',letterSpacing:1,color:c.muted}}>{label}</Txt></View>)}</View>
  <View style={{padding:20,borderWidth:1,borderColor:c.line,borderRadius:18,backgroundColor:c.surface,gap:18}}><View style={[styles.row,{justifyContent:'space-between'}]}><Txt style={{fontSize:16,fontWeight:'800'}}>A week of small wins</Txt><Icon name="bar-chart-2" size={18}/></View><View style={{flexDirection:'row',gap:12,alignItems:'flex-end'}}>{bars.map(b=><View key={b.date} style={{flex:1,alignItems:'center',gap:8}}><Txt style={{fontSize:11,fontWeight:'700'}}>{b.done}</Txt><View accessibilityLabel={`${b.date}: ${b.done} completed out of ${b.total}`} style={{height:100,width:'100%',justifyContent:'flex-end',backgroundColor:c.soft,borderRadius:6,overflow:'hidden'}}><View style={{height:b.total/maximum*100,backgroundColor:c.line,justifyContent:'flex-end'}}><View style={{height:b.done/maximum*100,backgroundColor:c.ink,borderRadius:4}}/></View></View><Txt style={{fontSize:10,color:b.date===day?c.ink:c.muted,fontWeight:b.date===day?'800':'500'}}>{utc(b.date).toLocaleDateString('en-US',{weekday:'narrow',timeZone:'UTC'})}</Txt></View>)}</View><Txt style={{fontSize:11,color:c.muted}}>Solid bars: completed · Gray bars: scheduled</Txt></View>
  <View style={{gap:14}}><Txt style={styles.label}>BY LABEL · LAST 7 DAYS</Txt>{data.lists.map(label=>{const tasks=rows.filter(o=>o.task.list===label),done=tasks.filter(o=>o.completedAt).length;return <View key={label} style={{gap:8}}><View style={[styles.row,{justifyContent:'space-between'}]}><View style={styles.row}><Icon name="tag" size={14}/><Txt style={{fontSize:13,fontWeight:'700'}}>{label}</Txt></View><Txt style={{fontSize:12,color:c.muted}}>{done} / {tasks.length}</Txt></View><View style={{height:4,backgroundColor:c.soft,borderRadius:4}}><View style={{height:4,width:`${tasks.length?done/tasks.length*100:0}%`,backgroundColor:c.ink,borderRadius:4}}/></View></View>;})}</View>
  <View style={styles.wrap}><Button icon="check-circle" onPress={()=>open('Completed')}>Completion history</Button><Button icon="layers" onPress={()=>open('All tasks')}>All tasks</Button></View>
 </View>;
}
