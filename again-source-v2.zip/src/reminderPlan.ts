import { Data, occurrences, addDays, today } from "./model";
export function reminderPlan(data: Data, now = new Date()) {
  if (!data.settings.notifications) return [];
  return occurrences(data, today(), addDays(today(), 60))
    .filter((o) => !o.completedAt && o.task.time && o.task.reminder !== null)
    .map((o) => ({
      id: o.key,
      title: o.task.title,
      ringtone: o.task.ringtone || "gentle",
      date: new Date(
        +new Date(o.date + "T" + o.task.time + ":00") -
          (o.task.reminder || 0) * 60000,
      ),
    }))
    .filter((x) => +x.date > +now)
    .sort((a, b) => +a.date - +b.date)
    .slice(0, 60);
}
