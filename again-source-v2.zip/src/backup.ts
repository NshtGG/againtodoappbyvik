import * as DocumentPicker from "expo-document-picker";
import { File, Paths } from "expo-file-system";
import * as Sharing from "expo-sharing";
import { Data, parseBackup } from "./model";
export async function exportData(data: Data) {
  const file = new File(Paths.cache, "again-backup.json");
  file.create({ overwrite: true });
  file.write(JSON.stringify(data, null, 2));
  if (await Sharing.isAvailableAsync())
    await Sharing.shareAsync(file.uri, { mimeType: "application/json" });
  else throw new Error("Sharing is not available on this device.");
}
export async function importData() {
  const result = await DocumentPicker.getDocumentAsync({
    type: ["application/json", "text/plain"],
    copyToCacheDirectory: true,
  });
  if (result.canceled) return null;
  return parseBackup(await new File(result.assets[0].uri).text());
}
