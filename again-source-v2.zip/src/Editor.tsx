import React, { useState } from "react";
import {
  Modal,
  View,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Pressable,
} from "react-native";
import {
  Task,
  Occurrence,
  Scope,
  Repeat,
  id,
  today,
  validateTask,
  dates,
  addDays,
  pretty,
  repeatLabel,
  editTask,
} from "./model";
import { useStore } from "./provider";
import { Txt, Button, Input, Icon, useTheme, styles } from "./ui";
import { Calendar } from "./Calendar";
export function Editor({
  occurrence,
  initialTitle = "",
  onClose,
}: {
  occurrence?: Occurrence;
  initialTitle?: string;
  onClose: () => void;
}) {
  const { data, commit, day } = useStore(),
    c = useTheme();
  const [task, setTask] = useState<Task>(
    occurrence
      ? { ...occurrence.task }
      : {
          id: id(),
          title: initialTitle,
          notes: "",
          start: day,
          time: "",
          repeat: "once",
          interval: 1,
          weekdays: [1, 3, 5],
          priority: 0,
          list: "Personal",
          reminder: null,
          ringtone: "gentle",
          checklist: [],
          createdAt: new Date().toISOString(),
        },
  );
  const [scope, setScope] = useState<Scope>("one"),
    [calendar, setCalendar] = useState<"start" | "end" | null>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [newLabel, setNewLabel] = useState(''),
    [checkItem, setCheckItem] = useState('');
  const patch = (p: Partial<Task>) => setTask({ ...task, ...p });
  const modes: [Repeat, string][] = [
    ["once", "One time"],
    ["daily", "Daily"],
    ["weekdays", "Weekdays"],
    ["weekly", "Weekly"],
    ["selected", "Selected days"],
    ["monthly", "Monthly"],
    ["intervalDays", "Every N days"],
    ["intervalWeeks", "Every N weeks"],
  ];
  async function submit() {
    const e = validateTask(task);
    if (e) {
      setError(e);
      return;
    }
    setBusy(true);
    try {
      await commit(
        (current) => {
          const labeled = {...current, lists: [...new Set([...current.lists, task.list])]};
          return occurrence
            ? editTask(
                labeled,
                occurrence,
                { ...task, title: task.title.trim() },
                occurrence.task.repeat === "once" ? "all" : scope,
              )
            : {
                ...labeled,
                tasks: [
                  ...current.tasks,
                  { ...task, title: task.title.trim() },
                ],
              };
        },
        occurrence ? "Task updated" : "Task added",
      );
      onClose();
    } catch {
      setError("Could not save. Please try again.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal visible animationType="slide" transparent onRequestClose={onClose}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={{
          flex: 1,
          backgroundColor: "#0009",
          justifyContent: "center",
          alignItems: "center",
          padding: 16,
        }}
      >
        <View
          style={{
            backgroundColor: c.bg,
            width: "100%",
            maxWidth: 640,
            maxHeight: "94%",
            borderRadius: 16,
            overflow: "hidden",
          }}
        >
          <View
            style={[
              styles.row,
              {
                padding: 24,
                borderBottomWidth: 1,
                borderColor: c.line,
                justifyContent: "space-between",
              },
            ]}
          >
            <View>
              <Txt style={styles.label}>MAKE ROOM FOR WHAT MATTERS</Txt>
              <Txt
                style={{ fontSize: 28, fontWeight: "900", letterSpacing: -1 }}
              >
                {occurrence ? "Edit task." : "A new beginning."}
              </Txt>
            </View>
            <Button small onPress={onClose} label="Close task editor">
              ✕
            </Button>
          </View>
          <ScrollView
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={{ padding: 24, gap: 22 }}
          >
            <Input
              label="WHAT DO YOU WANT TO DO?"
              autoFocus
              value={task.title}
              onChangeText={(title: string) => patch({ title })}
              placeholder="Give your next step a name"
              onSubmitEditing={submit}
            />
            <Input
              label="NOTES · OPTIONAL"
              multiline
              value={task.notes}
              onChangeText={(notes: string) => patch({ notes })}
              placeholder="A little context, a link, a plan…"
            />
            <View style={{ gap: 10, padding: 18, backgroundColor: c.soft, borderRadius: 12 }}>
              <View style={[styles.row,{justifyContent:'space-between'}]}><Txt style={styles.label}>CHECKLIST</Txt><Txt style={{fontSize:11,color:c.muted}}>{(task.checklist||[]).filter(i=>i.done).length}/{(task.checklist||[]).length}</Txt></View>
              {(task.checklist||[]).map(item=><View key={item.id} style={[styles.row,{backgroundColor:c.surface,borderRadius:9,paddingHorizontal:10}]}><Pressable accessibilityRole="checkbox" accessibilityState={{checked:item.done}} onPress={()=>patch({checklist:(task.checklist||[]).map(i=>i.id===item.id?{...i,done:!i.done}:i)})} style={{paddingVertical:12}}><Icon name={item.done?'check-square':'square'} size={18}/></Pressable><Txt style={{flex:1,fontSize:13,textDecorationLine:item.done?'line-through':'none',color:item.done?c.muted:c.ink}}>{item.text}</Txt><Pressable accessibilityRole="button" accessibilityLabel={`Remove ${item.text}`} onPress={()=>patch({checklist:(task.checklist||[]).filter(i=>i.id!==item.id)})} style={{padding:10}}><Icon name="x" size={16} color={c.muted}/></Pressable></View>)}
              <View style={styles.row}><View style={{flex:1}}><Input accessibilityLabel="New checklist item" placeholder="Add a smaller step…" value={checkItem} onChangeText={setCheckItem} maxLength={200} onSubmitEditing={()=>{const text=checkItem.trim();if(text){patch({checklist:[...(task.checklist||[]),{id:id(),text,done:false}]});setCheckItem('');}}}/></View><Button small icon="plus" label="Add checklist item" onPress={()=>{const text=checkItem.trim();if(text){patch({checklist:[...(task.checklist||[]),{id:id(),text,done:false}]});setCheckItem('');}}}>Add</Button></View>
            </View>
            {occurrence && occurrence.task.repeat !== "once" && (
              <View style={{ gap: 8 }}>
                <Txt style={styles.label}>APPLY CHANGES TO</Txt>
                <View style={styles.wrap}>
                  {(["one", "future", "all"] as Scope[]).map((s, i) => (
                    <Button
                      key={s}
                      small
                      primary={scope === s}
                      onPress={() => {
                        setScope(s);
                        patch({
                          start:
                            s === "future"
                              ? occurrence.date
                              : occurrence.task.start,
                        });
                        setCalendar(null);
                      }}
                    >
                      {["This occurrence", "This & future", "Whole series"][i]}
                    </Button>
                  ))}
                </View>
                <Txt style={{ fontSize: 12, color: c.muted }}>
                  Completed history keeps its original details.
                </Txt>
              </View>
            )}
            {!(
              occurrence &&
              scope === "one" &&
              occurrence.task.repeat !== "once"
            ) && (
              <>
                <View
                  style={{
                    gap: 10,
                    padding: 18,
                    backgroundColor: c.soft,
                    borderRadius: 10,
                  }}
                >
                  <Txt style={styles.label}>↻ REPEAT · BUILD YOUR RHYTHM</Txt>
                  <View style={styles.wrap}>
                    {modes.map(([r, label]) => (
                      <Button
                        key={r}
                        small
                        primary={task.repeat === r}
                        onPress={() => patch({ repeat: r })}
                      >
                        {label}
                      </Button>
                    ))}
                  </View>
                  {task.repeat === "selected" && (
                    <View style={styles.wrap}>
                      {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(
                        (s, n) => (
                          <Button
                            key={s}
                            small
                            primary={task.weekdays.includes(n)}
                            onPress={() =>
                              patch({
                                weekdays: task.weekdays.includes(n)
                                  ? task.weekdays.filter((x) => x !== n)
                                  : [...task.weekdays, n].sort(),
                              })
                            }
                          >
                            {s}
                          </Button>
                        ),
                      )}
                    </View>
                  )}
                  {task.repeat.startsWith("interval") && (
                    <Input
                      label="INTERVAL"
                      keyboardType="number-pad"
                      value={String(task.interval)}
                      onChangeText={(s: string) =>
                        patch({ interval: Number(s) })
                      }
                    />
                  )}
                  {task.repeat === "monthly" && (
                    <Txt style={{ fontSize: 12 }}>
                      Shorter months use their last calendar day.
                    </Txt>
                  )}
                </View>
                <View style={styles.wrap}>
                  <Button
                    onPress={() =>
                      setCalendar(calendar === "start" ? null : "start")
                    }
                    icon="calendar"
                  >
                    {scope === "one" && occurrence
                      ? "Occurrence"
                      : task.repeat === "once"
                        ? "Due date"
                        : "Starts"}
                    : {pretty(task.start, true)}
                  </Button>
                  {task.repeat !== "once" && (
                    <Button
                      onPress={() =>
                        setCalendar(calendar === "end" ? null : "end")
                      }
                    >
                      Until: {task.end ? pretty(task.end, true) : "No end date"}
                    </Button>
                  )}
                  {task.end && (
                    <Button small onPress={() => patch({ end: undefined })}>
                      Clear end
                    </Button>
                  )}
                </View>
                {calendar && (
                  <Calendar
                    value={task[calendar] || task.start}
                    onChange={(d) => {
                      patch({ [calendar]: d });
                      setCalendar(null);
                    }}
                  />
                )}
                {task.repeat !== "once" && (
                  <View style={{ gap: 8 }}>
                    <Txt style={styles.label}>YOUR NEXT OCCURRENCES</Txt>
                    <Txt style={{ fontSize: 13, color: c.muted }}>
                      {dates(task, task.start, addDays(task.start, 366))
                        .slice(0, 6)
                        .map((d) => pretty(d, true))
                        .join("  ·  ") || "No dates match this rule."}
                    </Txt>
                    <Txt style={{ fontSize: 11, color: c.muted }}>
                      End date is inclusive. Each day has its own checkbox.
                    </Txt>
                  </View>
                )}
              </>
            )}
            {occurrence &&
              scope === "one" &&
              occurrence.task.repeat !== "once" && (
                <Txt style={{ fontSize: 12, color: c.muted }}>
                  Editing {pretty(occurrence.date)}. Choose This &amp; future or
                  Whole series to change the schedule.
                </Txt>
              )}
            <Input
              label="TIME · OPTIONAL · 24-HOUR"
              placeholder="09:30"
              value={task.time}
              onChangeText={(time: string) =>
                patch({
                  time,
                  reminder: time
                    ? (task.reminder ?? data.settings.defaultReminder)
                    : null,
                })
              }
              maxLength={5}
              keyboardType="numbers-and-punctuation"
            />
            <View style={{ gap: 8 }}>
              <Txt style={styles.label}>REMIND ME</Txt>
              <View style={styles.wrap}>
                {[null, 0, 5, 15, 30, 60, 1440, 2880].map((n) => (
                  <Button
                    key={String(n)}
                    small
                    primary={task.reminder === n}
                    onPress={() => patch({ reminder: n })}
                  >
                    {n === null ? "Off" : n === 0 ? "At time" : n === 1440 ? "1 day before" : n === 2880 ? "2 days before" : `${n}m before`}
                  </Button>
                ))}
              </View>
              <Txt style={{ fontSize: 11, color: c.muted }}>
                Enable device reminders in Settings. Web keeps your time but
                cannot notify in the background.
              </Txt>
            </View>
            <View style={{gap:8}}><Txt style={styles.label}>CUSTOM RINGTONE</Txt><View style={styles.wrap}>{(['gentle','bright','focus','silent'] as const).map(tone=><Button key={tone} small primary={(task.ringtone||'gentle')===tone} icon={tone==='silent'?'volume-x':'music'} onPress={()=>patch({ringtone:tone})}>{tone[0].toUpperCase()+tone.slice(1)}</Button>)}</View><Txt style={{fontSize:11,color:c.muted}}>Each timed task can use its own reminder sound.</Txt></View>
            <View style={{ gap: 8 }}>
              <Txt style={styles.label}>PRIORITY</Txt>
              <View style={styles.wrap}>
                {[0, 1, 2, 3].map((n) => (
                  <Button
                    key={n}
                    small
                    primary={task.priority === n}
                    onPress={() => patch({ priority: n as any })}
                  >
                    {["None", "Low", "Medium", "High"][n]}
                  </Button>
                ))}
              </View>
            </View>
            <View style={{ gap: 8 }}>
              <Txt style={styles.label}>TASK LABEL</Txt>
              <View style={styles.wrap}>
                {[...new Set([...data.lists, task.list])].map((l) => (
                  <Button
                    key={l}
                    small
                    primary={task.list === l}
                    onPress={() => patch({ list: l })}
                  >
                    {l}
                  </Button>
                ))}
              </View>
            </View>
            <Input label="OR CREATE A CUSTOM LABEL" placeholder="e.g. Fitness, Side project…" value={newLabel} maxLength={60} onChangeText={setNewLabel}/>
            <Button small icon="plus" onPress={()=>{const name=newLabel.trim();if(!name)return;const existing=data.lists.find(l=>l.toLowerCase()===name.toLowerCase());patch({list:existing||name});setNewLabel('');}}>Use custom label</Button>
            {error && (
              <Txt accessibilityRole="alert" style={{ fontWeight: "700" }}>
                {error}
              </Txt>
            )}
          </ScrollView>
          <View style={{ padding: 20, borderTopWidth: 1, borderColor: c.line }}>
            <Button primary icon="check" disabled={busy} onPress={submit}>
              {busy ? "Saving…" : occurrence ? "Save changes" : "Add task"}
            </Button>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}
