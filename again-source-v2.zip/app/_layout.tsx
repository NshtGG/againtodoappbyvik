import React from "react";
import { Stack } from "expo-router";
import { Provider } from "../src/provider";
import { useTheme } from "../src/ui";
import { StatusBar } from "expo-status-bar";
function Layout() {
  const c = useTheme();
  return (
    <>
      <StatusBar style={c.dark ? "light" : "dark"} />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: c.bg },
        }}
      />
    </>
  );
}
export default function Root() {
  return (
    <Provider>
      <Layout />
    </Provider>
  );
}
