import { readdir, readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
async function walk(dir) {
  const files = [];
  for (const f of await readdir(dir, { withFileTypes: true })) {
    if (f.isDirectory()) files.push(...(await walk(path.join(dir, f.name))));
    else if (f.name !== "sw.js") files.push(path.join(dir, f.name));
  }
  return files;
}
const files = await walk("dist");
const hash = createHash("sha256");
for (const f of files) hash.update(await readFile(f));
const name = "again-" + hash.digest("hex").slice(0, 12);
const assets = [
  "/",
  ...files.map((f) => "/" + path.relative("dist", f).split(path.sep).join("/")),
];
await writeFile(
  "dist/sw.js",
  `const CACHE=${JSON.stringify(name)};const ASSETS=${JSON.stringify(assets)};
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('again-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||new URL(e.request.url).origin!==self.location.origin)return;e.respondWith(fetch(e.request).catch(()=>caches.match(e.request).then(r=>r||(e.request.mode==='navigate'?caches.match('/index.html'):Response.error()))));});`,
);
console.log("Offline cache generated:", name, assets.length, "assets");
